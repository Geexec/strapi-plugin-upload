'use strict';

/**
 * Lifecycle callbacks for the `File` model.
 */

module.exports = {};
