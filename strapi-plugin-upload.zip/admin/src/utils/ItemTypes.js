export default {
  MEDIA_CARD: 'mediaCard',
};
