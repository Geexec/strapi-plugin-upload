import { createContext } from 'react';

const InputModalDataManagerContext = createContext();

export default InputModalDataManagerContext;
