import styled from 'styled-components';

const SectionTitleWrapper = styled.div`
  margin-bottom: 20px;
`;

export default SectionTitleWrapper;
