import styled from 'styled-components';

const ControlsWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  padding-top: 1px;
`;

export default ControlsWrapper;
