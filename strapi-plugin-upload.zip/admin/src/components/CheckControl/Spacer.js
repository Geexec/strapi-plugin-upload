import styled from 'styled-components';

const Spacer = styled.div`
  height: 10px;
`;

export default Spacer;
