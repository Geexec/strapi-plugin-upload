import styled from 'styled-components';
import { Button } from '@buffetjs/core';

const FilterButton = styled(Button)`
  width: 100%;
`;

export default FilterButton;
