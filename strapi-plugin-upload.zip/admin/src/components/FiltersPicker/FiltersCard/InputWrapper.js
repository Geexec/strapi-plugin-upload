import styled from 'styled-components';

const InputWrapper = styled.div`
  margin-bottom: 11px;
  #datetime {
    max-width: 130px;
  }
`;

export default InputWrapper;
