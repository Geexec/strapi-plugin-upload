import styled from 'styled-components';

const Wrapper = styled.div`
  margin-bottom: 35px;
`;

export default Wrapper;
