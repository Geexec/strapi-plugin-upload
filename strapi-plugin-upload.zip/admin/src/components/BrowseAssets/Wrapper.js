import styled from 'styled-components';

const Wrapper = styled.div`
  width: 100%;
  padding-top: 0.6rem;
`;

export default Wrapper;
