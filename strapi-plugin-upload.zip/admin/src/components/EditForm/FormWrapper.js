import styled from 'styled-components';

const FormWrapper = styled.div`
  margin-top: 22px;
`;

export default FormWrapper;
