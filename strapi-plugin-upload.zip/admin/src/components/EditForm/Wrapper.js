import styled from 'styled-components';
import ContainerFluid from '../ContainerFluid';

const Wrapper = styled(ContainerFluid)`
  padding-top: 18px;
`;

export default Wrapper;
