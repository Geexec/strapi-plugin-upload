const isVideoType = mimeType => mimeType.includes('video');

export default isVideoType;
