const isImageType = mimeType => mimeType.includes('image');

export default isImageType;
