import styled from 'styled-components';

const ListTitle = styled.div`
  margin-top: 34px;
`;

export default ListTitle;
