import styled from 'styled-components';

const ButtonWrapper = styled.div`
  padding-top: 28px;
`;

export default ButtonWrapper;
