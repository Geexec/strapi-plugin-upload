import styled from 'styled-components';
import { Row } from 'reactstrap';

const ListRow = styled(Row)`
  padding-top: 13px;
`;

export default ListRow;
