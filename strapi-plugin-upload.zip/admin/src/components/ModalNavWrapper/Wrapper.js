import styled from 'styled-components';

const Wrapper = styled.div`
  max-height: 48.3rem;
  overflow: auto;
`;

export default Wrapper;
