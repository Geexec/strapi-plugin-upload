import styled from 'styled-components';

const ListWrapper = styled.div`
  margin-top: 1.5rem;
`;

export default ListWrapper;
