import styled from 'styled-components';

const ListTitleWrapper = styled.div`
  margin-top: 23px;
`;

export default ListTitleWrapper;
